package com.rest_apis.palyload;


import org.springframework.http.HttpStatusCode;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
public class Response {

	private String messgae;

	private String error;

	private Object data;

	private HttpStatusCode statusCode;

	@Override
	public String toString() {
		return "Response [messgae=" + messgae + ", error=" + error + ", data=" + data + ", statusCode=" + statusCode
				+ "]";
	}

	

}
