package com.rest_apis.serviceImpl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.modelmapper.ModelMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.rest_apis.entities.Lead;
import com.rest_apis.exceptions.ResourceNotFoundException;
import com.rest_apis.palyload.LeadModel;
import com.rest_apis.palyload.Response;
import com.rest_apis.repository.LeadRepo;
import com.rest_apis.service.LeadService;

@Service
public class LeadServiceImpl implements LeadService {

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private LeadRepo leadRepo;
	
	@Override
	public Response createLead(LeadModel leadModel) {
		// TODO Auto-generated method stub
		Response response = new Response();
		LeadModel leadModel1 = new LeadModel();
		Lead lead = new Lead();
		try {
			Date date = new SimpleDateFormat("dd/MM/yyyy").parse(leadModel.getDateOfBirth());
			BeanUtils.copyProperties(leadModel, lead);
			lead.setDateOfBirth(date);
			if (isValidMobileNumber(leadModel.getMobileNumber())) {
				Lead createdlead = this.leadRepo.save(lead);
				leadModel1 = this.leadToLeadModel(createdlead);
				return new Response("Created Successfully", null, leadModel1, HttpStatus.CREATED);
			} else {
				response.setMessgae("Invalid mobile number");
				response.setError(null);
				response.setData(null);
				response.setStatusCode(HttpStatus.BAD_REQUEST);
				return response;
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return response;

	}

	@Override
	public Response getLeadByMobileNumber(String mobileNumber) {
		Lead lead = this.leadRepo.getLeadByMobileNumber(mobileNumber);
		LeadModel leadModel = this.leadToLeadModel(lead);
		if (leadModel == null) {
			return new Response("Error while fetching record", null, null, HttpStatus.BAD_REQUEST);
		} else {
			return new Response("Fetch Successfully", null, leadModel, HttpStatus.FOUND);

		}

	}
	
	public Lead leadModelToLead(LeadModel leadModel) {

		Lead lead = this.modelMapper.map(leadModel, Lead.class);
		return lead;

	}

	public LeadModel leadToLeadModel(Lead lead) {

		LeadModel leadModel = this.modelMapper.map(lead, LeadModel.class);
		return leadModel;

	}
	
	public static boolean isValidMobileNumber(String mobileNumber) {
        String regex = "^(\\+\\d{1,3})?\\d{10}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(mobileNumber);
        return matcher.matches();
    }

}
