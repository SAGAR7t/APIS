package com.rest_apis.service;

import com.rest_apis.palyload.LeadModel;
import com.rest_apis.palyload.Response;


public interface LeadService {

	public Response createLead(LeadModel leadModel);

	public Response getLeadByMobileNumber(String mobileNumber);
}
